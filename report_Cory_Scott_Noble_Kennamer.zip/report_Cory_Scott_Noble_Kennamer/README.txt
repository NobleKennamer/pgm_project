Noble Kennamer Student I.D.: 77163775
Cory Scott Student I.D.: 7932600
CS 274B Homework 1

This directory contains our final project

The Files Included are:

1. clinton_report.pdf: This is our final paper.

2. interactive_model.html: Contains Interactive visualization for the high level topic models produced by HDP and LDA (see report for details of the visualization). Please open this file in some modern web browser We tested for Chrome, FireFox and Safari.

3. The Directory bipartite_graph: This directory contains the files to view the interactive plots between people and topics (details in the report). To view this visualization using a shell (i.e. bash) to navigate to the directory bipartite_graph and type “python -m SimpleHTTPServer 8888” (Or any valid port number you choose). Then using a modern web browser (We used Chrome) navigate to “http://localhost:8888” (or whatever port number you chose). Now you can click on the files bipartite_all.html and bipartite_specific.html to view the interactive visualizations.

All of the code for this project including the models we implemented and the code to create the visualizations can be found in the Public GitHub repo we used for this project. The URL for the public repo is:

https://github.com/NobleKennamer/pgm_project



